#number-triangle
rows=6
for i in range(1,rows+1):
    for j in range(1,i+1):
        print(j,end=" ")
    print()